package exam06;

public class Ex06Example {

	public static void main(String[] args) {
		Ex06 a1 = new Ex06("����",90,90,100);
		a1.display();
		Ex06 a2 = new Ex06("��ö��",80,70,90);
		a2.display();
		Ex06 a3 = new Ex06("�̿���",50,40,70);
		a3.display();
		Ex06 a4 = new Ex06("�ɿ���",70,80,60);
		a4.display();
		
	}

}
