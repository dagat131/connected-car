package exam16;

public class Cat extends Animal {
	public void animalSound() {
		System.out.println(" -- �� ��  -- ");
	}
}
