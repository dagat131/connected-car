package exam16;

public class Animal {
	void sound(Animal animal){
		animal.animalSound();
	}
	
	void animalSound() {
	System.out.println(" -- animal sound --");
	}
}
