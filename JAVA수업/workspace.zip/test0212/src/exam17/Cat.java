package exam17;

public class Cat implements Animal {

	@Override
	public void animalSound() {
		System.out.println("-- myong --");
		
	}

	@Override
	public void sleep() {
		System.out.println("-- Cat Zzz --");
		
	}

}
