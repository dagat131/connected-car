package exam17;

public interface Animal {
	public void animalSound();
	public void sleep();
}
