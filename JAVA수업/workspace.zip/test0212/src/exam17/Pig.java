package exam17;

public class Pig implements Animal {

	@Override
	public void animalSound() {
		System.out.println("-- ggul ggul --");
	}

	@Override
	public void sleep() {
		System.out.println("-- Pig Zzz --");
		
	}

}
