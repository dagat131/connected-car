package exam04;

public class SJ {
	String name; //null
	int kor; // 0
	int eng; // 0
	int mat; // 0
	int tot; // 0
	double avg; // 0.0
	

}
