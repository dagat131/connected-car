package example17;

public class Example {

	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.animalSound();
		dog.sleep();

	}

}
