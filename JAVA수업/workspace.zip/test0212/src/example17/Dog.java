package example17;

public class Dog extends Animal{

	@Override
	void animalSound() {
		System.out.println("-- bark bark --");
	}


}
