package exam03;

public class Ex01Example {

	public static void main(String[] args) {
		Ex01 v1 = new Ex01();
		String fname = v1.fname;
		String lname = v1.lname;
		int age = v1.age;
		
		System.out.println(fname + " " + lname);
		System.out.println(age);
		

	}

}
