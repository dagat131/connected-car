package exam03;

public class Ex01 {
	String fname = "ȫ";
	String lname = "�浿";
	int age = 19;
	
}
