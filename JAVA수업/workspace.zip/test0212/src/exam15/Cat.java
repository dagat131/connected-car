package exam15;

public class Cat extends Animal {
	public void animalSound(){
		System.out.println("-- �߿��� --");
	}
}
