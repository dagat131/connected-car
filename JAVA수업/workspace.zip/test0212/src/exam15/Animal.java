package exam15;

public class Animal {
	void sound(Animal animal) {
		animal.animalSound();
	}
	
	public void animalSound() {
		System.out.println("-- animal sound --");
	}
}
