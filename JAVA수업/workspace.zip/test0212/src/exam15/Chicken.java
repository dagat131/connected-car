package exam15;

public class Chicken extends Animal{
	public void animalSound() {
		System.out.println("-- ������ --");
}
}
