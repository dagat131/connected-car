package exam02;

public class MyClass {
	//����ʵ�.
	int x = 10;
	int y = 20;
	int z = 30;

}
