package exam07;

public class Ex07Example {

	public static void main(String[] args) {
		Ex07 e1 = new Ex07("����",90,90,100);
		e1.display();
		
		Ex07 e2 = new Ex07("��ö��",80,70,90);
		e2.display();

	}

}
