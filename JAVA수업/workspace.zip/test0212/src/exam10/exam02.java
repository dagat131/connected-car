package exam10;

class Test{
	private int a = 7;
}

public class exam02 {
	public static void main(String[] args) {
		Test t = new Test();
//		System.out.println(t.a);

	}

}
