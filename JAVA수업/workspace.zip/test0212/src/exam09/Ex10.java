package exam09;

public class Ex10 {
	
	//default ������
	public Ex10(){	
	}
	public Ex10(int x, int y){	
	}
	public Ex10(int x, String y){	
	}
	
	public static void main(String[] args) {
		
	}
}
