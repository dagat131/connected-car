package exam14;

public class Parent {
	int a = 7;
	String name = "ȫ�浿";
	
	void method1() {
		System.out.println("-- Parent method1() ����--");
	}
}
