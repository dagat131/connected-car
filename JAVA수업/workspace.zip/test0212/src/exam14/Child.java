package exam14;

public class Child extends Parent{
	int a = 5;
	int b = 17;
	
	void method1() {
		System.out.println("-- Child method1() ����--");
	}
	
}
