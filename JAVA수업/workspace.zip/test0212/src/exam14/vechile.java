package exam14;

public class vechile {
	protected String brand = "Ford";
	
	public void honk() {
		System.out.println("Tuut, Tuut!");
	}

	}


