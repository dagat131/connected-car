package exam19;

public class Example {

	public static void main(String[] args) {
		DemoClass dc = new DemoClass();
		dc.method1();
		dc.method2();
		
	}

}
